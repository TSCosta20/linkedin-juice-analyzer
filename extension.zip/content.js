(function(){"use strict";function M(e){let t=2166136261;for(let n=0;n<e.length;n++)t^=e.charCodeAt(n),t=t*16777619>>>0;return t.toString(16)}function g(e){return e.toLowerCase().replace(/[^a-z0-9\s]/g," ").split(/\s+/).filter(Boolean)}function d(e){return e.split(/[.!?]+/).map(t=>t.trim()).filter(Boolean)}function b(e){return e.trim()===""?0:e.trim().split(/\s+/).length}function c(e,t){return t.reduce((n,i)=>{const o=e.match(i);return n+(o?o.length:0)},0)}function w(e){const t=e.match(/\b\d+(\.\d+)?(%|x)?\b/g);return t?t.length:0}function E(e){const t=g(e),n=new Set;for(let i=0;i<t.length-1;i++)n.add(`${t[i]}_${t[i+1]}`);return n.size}const A=[/i'?ve been thinking (a lot )?about/gi,/here'?s what i'?ve learned/gi,/here'?s the thing/gi,/hot take:/gi,/unpopular opinion:/gi,/let me be (real|honest|clear)/gi,/nobody talks about/gi,/most people don'?t realize/gi,/\d+ (things?|lessons?|ways?|tips?|steps?|reasons?) (i|you|we)/gi,/i used to (think|believe)/gi,/story time/gi,/this changed (everything|my life|how i think)/gi,/what (nobody|no one) tells you/gi],I=[/\bfurthermore\b/gi,/\bmoreover\b/gi,/\bin conclusion\b/gi,/\bultimately\b/gi,/\bin summary\b/gi,/\bthe reality is\b/gi,/\bthe truth is\b/gi,/\bat the end of the day\b/gi,/\bit'?s (not|never) about\b/gi,/\bwhat (separates|sets apart)\b/gi,/\bwhen all is said and done\b/gi,/\bthe key (is|takeaway)\b/gi],z=[/what do you think\??/gi,/drop a comment/gi,/let me know (your thoughts|below|in the comments)/gi,/follow (for more|me for)/gi,/like (and|&) (share|repost)/gi,/tag someone who/gi,/agree or disagree\??/gi,/save this (post|for later)/gi,/repost (if|to)/gi,/👇+/g],C=[/\bgame.?changer\b/gi,/\bparadigm shift\b/gi,/\bthought leader(ship)?\b/gi,/\bempower(ing|ment)?\b/gi,/\btransform(ation|ative|ing)?\b/gi,/\bjourney\b/gi,/\bauthentic(ity)?\b/gi,/\bhustle\b/gi,/\bgrind\b/gi,/\bgrowth mindset\b/gi,/\bnext level\b/gi,/\blevel up\b/gi,/\bleverage\b/gi,/\bimpactful\b/gi];function T(e){const t=d(e).filter(a=>a.split(/\s+/).length>3);if(t.length<3)return 0;const n=t.map(a=>b(a)),i=n.reduce((a,r)=>a+r,0)/n.length,o=n.reduce((a,r)=>a+Math.pow(r-i,2),0)/n.length,s=Math.sqrt(o),l=i>0?s/i:1;return Math.max(0,1-l)}function N(e){const t=(e.match(/^\s*\d+[\.\)]/gm)||[]).length,n=(e.match(/^\s*[•\-\*]/gm)||[]).length;return Math.min((t+n)/5,1)}function x(e){if(!e.trim())return 0;let t=0;const n=c(e,A);t+=Math.min(n*10,20);const i=c(e,I);t+=Math.min(i*5,15);const o=c(e,z);t+=Math.min(o*7,15);const s=c(e,C);t+=Math.min(s*4,20),t+=Math.round(T(e)*15),t+=Math.round(N(e)*15);const l=d(e).filter(Boolean),a=g(e);if(l.length>0&&a.length>10){const r=a.length/l.length;r>=12&&r<=28&&(t+=5)}return Math.min(Math.round(t),100)}const P=[/\bleverage[sd]?\b/gi,/\bsynerg(y|ies|istic)\b/gi,/\bparadigm(s| shift)?\b/gi,/\bdisrupt(ive|ion|ing)?\b/gi,/\binnovati(ve|on|ng)\b/gi,/\bgame.?changer?\b/gi,/\bthought leader(ship)?\b/gi,/\bhustle\b/gi,/\bgrind\b/gi,/\bjourney\b/gi,/\bauthentic(ity)?\b/gi,/\btransform(ation|ative|ing|ed)?\b/gi,/\becosystem\b/gi,/\bbandwidth\b/gi,/\bpivot(ing|ed)?\b/gi,/\bscal(e|ing|able)\b/gi,/\bimpact(ful)?\b/gi,/\bempower(ing|ment|ed)?\b/gi,/\bstakeholder(s)?\b/gi,/\bdeliverable(s)?\b/gi,/\bmove the needle\b/gi,/\bvalue proposition\b/gi,/\bpain point(s)?\b/gi,/\blow.?hanging fruit\b/gi,/\bdeep dive\b/gi,/\bcircle back\b/gi,/\btake it offline\b/gi,/\bblue.?sky thinking\b/gi,/\bthink outside the box\b/gi,/\bnext level\b/gi,/\bgrowth mindset\b/gi,/\bworld.?class\b/gi,/\bbest.?in.?class\b/gi,/\bfast.?paced\b/gi,/\bever.?evolving\b/gi,/\bdigital (transformation|landscape)\b/gi,/\bpassion(ate)?\b/gi,/\bexcellence\b/gi,/\bsynergy\b/gi,/\brobust\b/gi,/\bseamless(ly)?\b/gi,/\bholistic(ally)?\b/gi],R=[/\bincredibly\b/gi,/\bmassively\b/gi,/\bhugely\b/gi,/\babsolutely\b/gi,/\bunbelievably\b/gi,/\bamazingly\b/gi,/\bpowerful\b/gi,/\bground.?breaking\b/gi,/\bsignificant(ly)?\b/gi,/\bdramatic(ally)?\b/gi,/\btremendous(ly)?\b/gi,/\bphenomenal(ly)?\b/gi],_=[/\bsuccess (is|requires|comes from)\b/gi,/\b(leaders?|leadership) (don'?t|must|should|need to)\b/gi,/\bthe (future|world) (of|is|needs)\b/gi,/\bdon'?t (just|only|wait)\b/gi,/\bbe the change\b/gi,/\bmake an impact\b/gi,/\bchase your dream\b/gi,/\bnever stop (learning|growing|hustling)\b/gi,/\bthe (real )?secret (to|of|is)\b/gi,/\bstay (hungry|humble|authentic|focused)\b/gi,/\bthe (power|importance|value) of\b/gi];function $(e){if(!e.trim())return 0;const t=b(e);if(t<5)return 0;let n=0;const o=c(e,P)/t;n+=Math.min(Math.round(o*300),35);const s=c(e,R);n+=Math.min(s*4,20);const l=c(e,_);n+=Math.min(l*7,20);const a=w(e);t>40&&a===0?n+=15:t>40&&a<=1&&(n+=7);const r=g(e),p=r.filter(y=>y.endsWith("ly")||y.endsWith("ive")&&y.length>5).length,oe=r.length>0?p/r.length:0;return n+=Math.min(Math.round(oe*60),10),Math.min(Math.round(n),100)}const B=[/\bfor example\b/gi,/\bfor instance\b/gi,/\bspecifically\b/gi,/\bsuch as\b/gi,/\baccording to\b/gi,/\bresearch (shows?|suggests?|finds?)\b/gi,/\bdata (shows?|suggests?|indicates?)\b/gi,/\bwe (found|discovered|measured|observed|tested)\b/gi,/\bthe result(s)? (was|were|showed?|is)\b/gi,/\bthis (means?|resulted? in|caused?|led to)\b/gi,/\bbecause\b/gi,/\btherefore\b/gi,/\bwhich (means?|resulted?|caused?|led)\b/gi,/\bproved?\b/gi,/\bshowed?\b/gi,/\bend result[s]?:/gi,/\boutcome[s]?:/gi,/\bkey (changes?|findings?|takeaways?):/gi,/\breduced? (by|from) \d/gi,/\bincreased? (by|from) \d/gi,/\bdropped? (from|by|to) \d/gi,/\bimproved? (by|from) \d/gi,/\bfrom \d+\S* to \d/gi],L=[/\bin today'?s (world|landscape|market|era|environment)\b/gi,/\bthe (power|importance|value|beauty) of\b/gi,/\bwe all know\b/gi,/\bit'?s no secret\b/gi,/\blet'?s be honest\b/gi,/\bremember:/gi,/\bfood for thought\b/gi,/\btake a moment to\b/gi,/\bask yourself\b/gi,/\bat the end of the day\b/gi,/\bthe bottom line is\b/gi,/\btruth be told\b/gi,/\bwhen all is said and done\b/gi];function O(e){const t=g(e);if(t.length<4)return 0;const n=t.length-1,o=E(e)/n;return Math.round((1-o)*20)}function q(e,t){const n=b(e);if(n<20)return 0;const i=t/n;return i>=.05?0:i>=.03?10:i>=.01?20:30}function H(e){if(!e.trim()||b(e)<5)return 0;let n=0;const i=w(e);n+=Math.min(i*5,25);const o=c(e,B);n+=Math.min(o*5,25);const s=(e.match(/\b(https?:\/\/\S+|v\d+\.\d+[\w.]*|\d+ms|\d+s\b|\d+%|\d+x\b|\$[\d,]+|[A-Z]{2,}[a-z]*\d+|[A-Z]{3,}\b)\b/g)||[]).length;n+=Math.min(s*4,20);const l=(e.match(/\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b/g)||[]).length;n+=Math.min(l*2,10);const a=d(e).filter(p=>b(p)>4);n+=Math.min(a.length*2,10);const r=c(e,L);return n-=Math.min(r*5,20),n-=O(e),n-=q(e,i+o+s),Math.max(0,Math.min(Math.round(n),100))}const D=["unmistakably human","very human feel","mostly human","human with slight polish","mixed signals","noticeably AI-shaped","likely AI-assisted","strong AI fingerprints","almost certainly AI-written","textbook AI output"],U=["zero fluff","very low fluff","mostly clean","minor buzzword noise","moderate bullshit","noticeable bullshit","heavy buzzword load","very buzzwordy","bullshit overdrive","pure thought-leadership"],Z=["nothing of substance","almost no juice","very low juice","low juice","some juice","decent juice","good juice","solid juice","high juice","pure signal"];function u(e){return Math.min(Math.floor(e/10),9)}function G(e,t,n){const i=D[u(e)],o=U[u(t)],s=Z[u(n)],l=`${i}, ${o}, ${s}.`;return l.charAt(0).toUpperCase()+l.slice(1)}function J(e){const t=x(e),n=$(e),i=H(e),o=G(t,n,i);return{ai:t,bullshit:n,juice:i,summary:o}}const V=[".feed-shared-update-v2__description .update-components-text",".update-components-text",".feed-shared-update-v2__description",".feed-shared-text-view",".feed-shared-inline-show-more-text",'[data-test-id="main-feed-activity-card"] .feed-shared-text'],W=[".feed-shared-update-v2",'[data-urn*="activity"]','[data-id*="urn:li:activity"]'],F=[".feed-shared-actor",".feed-shared-footer",".social-actions",".feed-shared-social-action-bar","button",".artdeco-button",".lja-card"].join(", ");function K(){for(const e of W){const t=Array.from(document.querySelectorAll(e));if(t.length>0)return t}return[]}function X(e){for(const i of V){const o=e.querySelector(i);if(o){const s=(o.innerText??o.textContent??"").trim();if(s.length>20)return s}}const t=e.cloneNode(!0);t.querySelectorAll(F).forEach(i=>i.remove());const n=(t.innerText??t.textContent??"").trim();return n.length>20?n:null}function Y(){const e=K(),t=[];for(const n of e){const i=X(n);i&&t.push({container:n,textContent:i})}return t}const Q=`
.lja-card {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 5px 10px;
  padding: 6px 14px 6px 16px;
  margin: 2px 0;
  border-top: 1px solid rgba(0,0,0,0.07);
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  font-size: 11.5px;
  line-height: 1.4;
  color: #555;
  background: transparent;
  user-select: none;
  box-sizing: border-box;
}

.lja-metric {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.lja-label {
  font-weight: 600;
  font-size: 9.5px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: #999;
}

.lja-score {
  display: inline-block;
  min-width: 26px;
  padding: 1px 5px;
  border-radius: 4px;
  font-weight: 700;
  font-size: 11px;
  text-align: center;
  letter-spacing: -0.02em;
}

/* AI score: high = bad (red), low = good (green) */
.lja-ai-low  { background: #dcf5e4; color: #1a6630; }
.lja-ai-mid  { background: #fff4cd; color: #7a5500; }
.lja-ai-high { background: #fde8e8; color: #9b1c1c; }

/* BS score: high = bad (red), low = good (green) */
.lja-bs-low  { background: #dcf5e4; color: #1a6630; }
.lja-bs-mid  { background: #fff4cd; color: #7a5500; }
.lja-bs-high { background: #fde8e8; color: #9b1c1c; }

/* Juice score: high = good (green), low = bad (red) — inverted */
.lja-juice-low  { background: #fde8e8; color: #9b1c1c; }
.lja-juice-mid  { background: #fff4cd; color: #7a5500; }
.lja-juice-high { background: #dcf5e4; color: #1a6630; }

.lja-sep {
  color: #ddd;
  font-size: 12px;
  font-weight: 300;
}

.lja-summary {
  width: 100%;
  color: #888;
  font-size: 10.5px;
  font-style: italic;
  margin-top: 0;
}
`;let j=!1;function ee(){if(j)return;const e=document.createElement("style");e.id="lja-styles",e.textContent=Q,document.head.appendChild(e),j=!0}function h(e,t){if(t==="juice")return e>=60?"lja-juice-high":e>=30?"lja-juice-mid":"lja-juice-low";const n=`lja-${t}-low`,i=`lja-${t}-mid`,o=`lja-${t}-high`;return e>=60?o:e>=30?i:n}function te(e,t){const n=document.createElement("div");return n.className="lja-card",n.dataset.ljaHash=t,n.innerHTML=`
    <span class="lja-metric">
      <span class="lja-label">AI</span>
      <span class="lja-score ${h(e.ai,"ai")}">${e.ai}</span>
    </span>
    <span class="lja-sep">·</span>
    <span class="lja-metric">
      <span class="lja-label">BS</span>
      <span class="lja-score ${h(e.bullshit,"bs")}">${e.bullshit}</span>
    </span>
    <span class="lja-sep">·</span>
    <span class="lja-metric">
      <span class="lja-label">Juice</span>
      <span class="lja-score ${h(e.juice,"juice")}">${e.juice}</span>
    </span>
    <span class="lja-summary">${e.summary}</span>
  `.trim(),n}function ne(e){return e.querySelector(".feed-shared-social-action-bar")??e.querySelector(".social-actions")??e.querySelector(".feed-shared-footer")??e}function v(e,t,n){if(ee(),e.querySelector(`[data-lja-hash="${n}"]`))return!1;const i=ne(e),o=te(t,n);return i.insertAdjacentElement("beforebegin",o),!0}let f=null;function ie(e){if(f)return;let t=null;f=new MutationObserver(n=>{n.some(o=>o.addedNodes.length>0)&&(t&&clearTimeout(t),t=setTimeout(()=>{e(),t=null},400))}),f.observe(document.body,{childList:!0,subtree:!0})}const m=new Map;function S(){const e=Y();for(const{container:t,textContent:n}of e){const i=M(n);if(m.has(i)){const s=m.get(i);v(t,s.score,i);continue}const o=J(n);m.set(i,{hash:i,score:o}),v(t,o,i)}}function k(){S(),ie(S)}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",k):k()})();
